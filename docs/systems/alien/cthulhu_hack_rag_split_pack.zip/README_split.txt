Cthulhu Hack RAG split pack

Rules entries: 210
Scenario entries: 226
Other entries: 0

Files:
- cthulhu_hack_rules_rag.jsonl
- cthulhu_hack_scenarios_rag.jsonl
- cthulhu_hack_other_rag.jsonl
- cthulhu_hack_clean.txt
- cthulhu_hack_clean.md
- cthulhu_hack_split_metadata.json
