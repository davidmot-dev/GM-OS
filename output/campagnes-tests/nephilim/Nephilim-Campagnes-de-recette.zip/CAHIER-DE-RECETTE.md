# 70 essais Nephilim — NON TESTÉS par David

Références : manuel 54-Jeu-Nephilim.md, pilote 2.0.0, moteurs nephilim/nephilimRegles et Livre 0/errata V1.3 déjà audités. Les profils de pouvoirs RECETTE ne sont pas officiels. Les états des laboratoires ne sont pas des actions déjà jouées ; repartir du laboratoire avec Remplacer entre essais indépendants.

| Cas | Archive | Précondition | Action | Attendu |
| --- | --- | --- | --- | --- |
| NE-01 | 01 | Vécu 4 et Ka 4 | Composer le jet puis comparer avec approche vide. | 80 % avec Ka, 40 % sans ; la somme des degrés est multipliée par dix. |
| NE-02 | 01 | Jet au-delà de dix degrés | Ajouter une circonstance autorisée puis comparer la marge. | Chances au-delà de 100 possibles ; degrés au-delà de dix ajoutés à la marge. |
| NE-03 | 01 | D100 naturel | Observer doubles réussis/ratés et 00 au cours des essais. | Double réussi critique, double raté maladresse, 00 toujours en échec ; ne pas truquer un tirage. |
| NE-04 | 01 | Vécus présents et lignes vides | Ouvrir les menus puis le référentiel du Vécu passé. | Noms lisibles, liens vers les époques exactes ; ligne sans nom absente du jet. |
| NE-05 | 03 | A01 Grand Secret nommé et A03 Œuvre rouge nommée | Comparer les options de troisième cercle avant/après effacement du nom sur copies. | Champ nommé proposé ; champ sans nom masqué. Aucun pouvoir officiel inventé sous ce nom de recette. |
| NE-06 | 02/03 | Contextes du bandeau | Comparer Plexus Feu, Nexus et conjonction simple/grande. | Bonus et oppositions du moteur selon l’élément ; rien sans Ka au jet. |
| NE-07 | 02 | S01 trois cases et Conséquence mineure | Comparer un jet physique puis non physique. | −2 au Vécu, minimum zéro, avant ajout du Ka ; pas de malus physique automatique sur toute action. |
| NE-08 | 02 | S02 Conséquence magique sérieuse | Lancer un Art puis un Vécu. | −4 à l’Art ; la conséquence magique ne pénalise pas le métier du Simulacre. |
| NE-09 | 01 | Santé saine | Proposer 2 degrés physiques puis choisir la case minimale suffisante. | Une case de valeur 2, pas deux cases de valeur 1 ; compte des cases mis à jour. |
| NE-10 | 02 | S01 | Proposer des dommages avec Conséquences et case restante. | Seulement les combinaisons suffisantes autorisées ; aucun choix appliqué à l’aperçu. |
| NE-11 | 01 | Nahal Ka-Terre 6 | Comparer cases physiques de bonus et piste magique. | Une case physique supplémentaire de 1 ouverte ; pas de case magique de bonus. |
| NE-12 | 02 | Cases cochées et Conséquence | Confirmer cinq minutes de repos sur une piste. | Cases temporaires décochées ; Conséquence conservée. |
| NE-13 | 02 | Conséquence cochée | Comparer durée physique et magique à Ka-Terre connu. | 11 − Ka-Terre, unités de gravité distinctes ; pas de guérison au rechargement. |
| NE-14 | 02 | S02 magique sérieuse, Stase 4 | Transférer la Conséquence magique à la stase sur copie. | Coût en degrés appliqué une fois ; insuffisance signalée, pas de stase négative. |
| NE-15 | 02 | Piste physique saturée sur copie | Proposer un dommage que rien n’absorbe. | Hors de combat proposé explicitement, jamais décès par simple case cochée. |
| NE-16 | 02 | Piste magique saturée sur copie | Proposer un dommage que rien n’absorbe. | Degré de Chute choisi avec le MJ ; pas de dommage physique automatique. |
| NE-17 | 02 | Chutes préparées | Comparer paliers 0, 1–4, 5–7, 8–9 et 10. | Effets, injouabilité temporaire puis perte définitive distincts. |
| NE-18 | 02 | S03 Nanisme 5, sort degré 5 | Tenter le sort au panneau. | Lancer bloqué par l’interdit du Khaïba. |
| NE-19 | 02 | S04 Gigantisme 5, dominant Feu | Tenter la Magie au Ka-Feu puis une approche permise sur copie. | Interdit sur Magie du Ka dominant, pas sur tous les jets. |
| NE-20 | 02 | S05 forme éthérale 5, formule Terre | Préparer Alchimie au Ka-Terre du construct. | Formule du Ka dominant interdite ; choisir la formule/approche cohérente. |
| NE-21 | 02 | S06 forme élémentaire 5, invocation Eau | Préparer Hod et Ka-Eau. | Invocation du Ka dominant interdite. |
| NE-22 | 02 | S07 Ombre 8 | Lire l’alerte et ramener à 7 sur copie après décision du MJ. | Confié au MJ à 8 ; statut narratif explicite, pas mort physique. |
| NE-23 | 02 | S08 Narcose 10 | Lire le palier et conserver le personnage comme témoin de test. | Perte définitive signalée ; aucune suppression automatique du PJ. |
| NE-24 | 02 | S09 Khaïba 3 déjà mise en jeu, PS de Chute 2 | Tenter une seconde mise en jeu puis un Effet Mnémos. | Pas de second gain dans la séance ; PS de Chute employés avant les PS ordinaires. |
| NE-25 | 03 | A03 Materiae Lune 1 | Valider Début de séance, puis vérifier les trois Chutes sur S09 dans un essai séparé. | MP restaurées à leur maximum saisi ; mises en jeu et PS de Chute effacés, pas Sapience ordinaire. |
| NE-26 | 01 | Ka dominant 6, Stase 4 | Comparer choix dominant, degré calculé et jauge de Stase. | Plafond sur le Ka choisi, stase bornée ; une baisse de Ka signale une réserve périmée. |
| NE-27 | 01 | Réserves de personnage | Puiser deux degrés de Stase puis lancer une action autorisée. | Coût au lancer une fois ; approche/métamorphe ne deviennent pas des ressources distinctes. |
| NE-28 | 01 | Vécu passé | Ajouter un Effet Mnémos de bonus puis lancer. | Coût en PS annoncé ; ne pas confondre bonus et Mnémos en tant que Vécu. |
| NE-29 | 02 | S09 PS de Chute | Choisir Mnémos en tant que Vécu de deux degrés. | Deux PS, plafonné par le Vécu passé ; consommation prioritaire des PS de Chute. |
| NE-30 | 01 | Métamorphe degré 2 | Exprimer un puis deux degrés sur le Ka dominant. | Bonus limité aux degrés non permanents ; autres approches non couvertes. |
| NE-31 | 01 | Métamorphose rendue permanente sur copie | Relire le degré exprimable puis reconnecter. | Degré permanent déjà visible retiré de la réserve exprimable ; aucune seconde coche automatique. |
| NE-32 | 01 | Action sociale | Choisir Impressionner puis lancer. | +2 et un jeton de Traque ; coût visible et non rejoué. |
| NE-33 | 02 | RK 3, chutes au-delà de 4 | Comparer le calcul de dépassement. | Approche, exprimé, visible et degrés de Chute au-delà de 4 pris en compte selon le moteur. |
| NE-34 | 01 | Traque 1, Seuil RK 5 | Ajouter quatre jetons explicitement au bandeau. | Au seuil, jauge vidée et Intensité +1 immédiatement : choix de David, distinct de l’aube de l’errata. |
| NE-35 | 02 | Intensité de Traque 2 puis 3 sur copie | Noter avec le MJ le sacrifice/l’élément interdit. | Restrictions narrées explicitement ; ne pas attribuer au logiciel une sélection automatique de tous les interdits. |
| NE-36 | 01 | Astérion, sort de recette degré 2 | Choisir Basse Magie 4, Ka-Feu 6 et le sort. | 80 % avant circonstances : (4 + 6 − 2) × 10 ; nom, élément et coût lisibles. |
| NE-37 | 01/03 | Sapience 12 puis A01 Sapience 4 | Préparer un Sacrifice avec un sort admissible puis inadmissible sur copies. | Coût 5 PS et réussite automatique si autorisé ; insuffisance et degré au-delà de l’Art refusés. |
| NE-38 | 01 | Sort raté sans maladresse | Retenter avec 1 PS puis, sur autre copie, 1 Stase. | Prix payé une fois et relance immédiate ; focus/arbitrage confirmés à la table. |
| NE-39 | 01 | Critique d’Art | Choisir noter 1 PS ou soigner immédiatement un degré de Chute. | Deux usages exclusifs ; pas de double récompense. |
| NE-40 | 01 | Ismérie, Hod 4, Eau 6, créature 2 | Réussir l’invocation puis ouvrir le pacte. | Ordonnances distinctes, deux d100 comparés par la table d’opposition ; pacte pas noué au chargement. |
| NE-41 | 03 | A02 invocation 3 | Résoudre un pacte perdu puis encaisser. | Dommages magiques de degré 3, aucune écriture physique inventée. |
| NE-42 | 03 | Pacte sur maladresse | Lire le bannissement et sa condition de fin. | Banni du fief jusqu’à un degré de plus dans la Sephirah ; pas de pacte lié après l’échec. |
| NE-43 | 01 | Nahal, Œuvre noire 4, cornue Eau 4, formule 2 | Lancer la transmutation et examiner les Materiae. | 60 % avant contexte ; Eau −2 sauf critique, aucune double consommation. |
| NE-44 | 03 | A03 formule Lune/Lune degré 2 | Lancer puis examiner les deux consommations. | Même jauge Lune payée deux fois ; insuffisance détaillée, pas de réserve négative. |
| NE-45 | 03 | A03 cornue Eau 4 et Lune 3 | Préparer l’Œuvre au blanc avec la formule à second élément Lune. | Moins développé des deux Ka du construct retenu. |
| NE-46 | 03 | A03 assemblage blanc et Œuvre rouge nommée | Tenter la transmutation de niveau supérieur. | Lancer bloqué si l’assemblage est insuffisant. |
| NE-47 | 03 | A03 Materiae insuffisantes | Examiner le reliquat dû après le lancer. | Jauge arrêtée à zéro ; complément à prendre ailleurs explicitement avec le MJ. |
| NE-48 | 01 | Maladresse d’Alchimie | Appliquer +1 Khaïba puis Construct abîmé après lecture. | Forme éthérale si premier Khaïba ; Ka du construct −1 au bouton, pas formule retentée dans le scénario. |
| NE-49 | 01 | Fin de séance et PS disponibles | Préparer un achat de Vécu, d’Art, de Ka et de maximum MP sur copies. | Prix du degré suivant selon le moteur ; un premier Ka nécessite Mnémos permanent. |
| NE-50 | 01 | Stase entamée | Confirmer un jour en Plexus/Nexus, sortie de stase, puis test sur copies. | +1 par jour, pas par heure ; plafond respecté ; test sur Ka actuel sans modificateur. |
| NE-51 | 01 | PNJ humains | Ouvrir les fiches de Maëlle et Ruben puis un Nephilim. | Métier humain et Ka-Soleil sans Arts occultes gratuits ; Menace/initiative humaine à arbitrer selon le livre. |
| NE-52 | 01 | Rencontre préparée | Ajouter les Nephilim, lire Ka-Eau ×2 puis annoncer les priorités. | Initiative de base correcte ; PS, sorts préparés et tirs visés restent à déclarer explicitement. |
| NE-53 | 01 | Trois rencontres évitables | Négocier, contourner puis engager une copie de rencontre. | Bons alliés/hostiles et profils de recette ; pas de combat imposé pour obtenir une preuve. |
| NE-54 | 01 | Changement de lieu Atlas | Suivre CONTEXTE-DES-LIEUX.json et régler le bandeau. | Contexte proposé, jamais appliqué automatiquement par le fichier de données. |
| NE-55 | Toutes | Joueurs existants p-1/p-2/p-3 | Importer les trois archives telle quelle. | Profils, avatars et anciens PJ conservés ; quinze nouveaux personnages au total. |
| NE-56 | 01 | Trois tablettes 360/768/1180 | Choisir le bon PJ et lancer un Vécu avec approche. | Jet reçu par le MJ ; formules/sorts facultatifs peuvent rester vides. |
| NE-57 | 01 | Fiche HTML | Ouvrir les sept pages, modifier une valeur puis sortir du champ. | Nom du Nephilim/Simulacre distincts, valeurs remontées ; copies calculées en lecture seule. |
| NE-58 | 01 | Marqueur de secrets de séance | Inspecter les messages joueur. | Aucun SECRET_MJ_NEPHILIM_RECETTE attendu ; consigner GM-05 en échec s’il persiste. |
| NE-59 | 01 | Atlas et indices | Ouvrir huit lieux et révéler/recacher une preuve. | Liens exacts ; I01 seul révélé au départ. |
| NE-60 | 01 | Trame quatre actes | Suivre les trois issues puis l’atelier hors fiction. | Chaînes reliées, aucune preuve essentielle dépendante d’un jet unique. |
| NE-61 | 01 | 101 euros fictifs | Partager 33 chacun puis conserver le reliquat. | 99 distribués, reste 2 ; pas de conversion des objets en Sapience ou Materiae. |
| NE-62 | 01 | Wiki et Chronologie | Lire neuf pages et quatre repères. | Pentacle descriptif, dates ISO fictives ; aucun calendrier ésotérique affirmé. |
| NE-63 | 01 | Sons, musique et Storyboard | Écouter trois sons et deux pistes, déclencher quatre moments puis arrêter. | Médias locaux, sons synthétiques 4 s ; rien ne démarre à l’import. |
| NE-64 | 01 | Light-OS | Assigner les appareils de test aux trois tuiles. | États matériels vides à la livraison ; aucun appareil déclaré validé. |
| NE-65 | Tables | Atelier Table-OS | Importer les trois JSON dans un univers de recette, Ranger tel quel. | Trois tables originales 1d6 ; aucune table officielle remplacée. |
| NE-66 | 02/03 | Laboratoire altéré | Réimporter uniquement ce laboratoire avec Remplacer. | Fiches et réserves du laboratoire remises à zéro ; enquête 01 préservée. |
| NE-67 | 01 | Après modification | Exporter puis importer avec Cloner. | Liens et personnages cohérents, original conservé. |
| NE-68 | Toutes | Clôture et reconnexion | Recharger puis comparer les fiches et réserves. | Écritures persistées, pas de coût ni gain de séance rejoué à la connexion. |
| NE-69 | Toutes | Catalogue des modules | Ouvrir Modules du jeu sous ce pilote. | Aucun module spécifique compatible dans cette version ; les outils transversaux et cartes natives suffisent au lot. |
| NE-70 | Toutes | Après chaque essai | Renseigner observé, verdict et preuve dans resultats.csv. | PASSÉ, ÉCHEC, NON TESTÉ ou NON APPLICABLE ; aucun cas humain prévalidé. |
