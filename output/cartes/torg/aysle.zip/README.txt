Aysle — extraction vérifiée le 08/11/2026

Action : 40.jpg à 79.jpg et back.jpg (paysage).
Cosm Aysle : 11.jpg à 20.jpg et back.jpg (portrait).
Destin : 6.jpg à 10.jpg et back.jpg (portrait).

Les noms de fichiers suivent les départs demandés ; les numéros imprimés restent inchangés.
58 JPEG identiques lors de deux extractions indépendantes. Recette et manifeste inclus.
Les 110 pages sont couvertes ; 52 répétitions de dos regroupées, aucune face supprimée.
Les illustrations raster restent limitées par la netteté du PDF source.

Rejeu avec Python, PyMuPDF 2.0 et Pillow 12.1.1 :
python reproduction/cards.py extract recipe.json --source s0 "CHEMIN_DU_PDF_SOURCE.pdf" --out "aysle-rejoue"
Le dossier de sortie et le ZIP voisin doivent être inexistants.
