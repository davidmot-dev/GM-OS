Cyberpapauté — extraction vérifiée le 08/11/2026

Action : 160.jpg à 199.jpg et back.jpg (paysage).
Cosm Cyberpapauté : 10.jpg à 19.jpg et back.jpg (portrait).
Destin : 76.jpg à 80.jpg et back.jpg (portrait).

Les noms suivent les départs demandés ; les numéros imprimés restent inchangés.
58 JPEG identiques lors de deux extractions indépendantes.
Les 110 pages sont couvertes ; 52 répétitions de dos regroupées, aucune face supprimée.
Les détails raster restent limités par la résolution du PDF source.

Rejeu avec Python, PyMuPDF 2.0 et Pillow 12.1.1 :
python reproduction/cards.py extract recipe.json --source s0 "CHEMIN_DU_PDF_SOURCE.pdf" --out "cyberpapaute-rejoue"
Le dossier de sortie et le ZIP voisin doivent être inexistants.
