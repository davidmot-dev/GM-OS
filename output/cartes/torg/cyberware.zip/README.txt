Cyberware — extraction vérifiée le 08/11/2026

Cyberware : 0.jpg à 54.jpg et back.jpg (portrait).

Les noms suivent les départs demandés ; les numéros imprimés restent inchangés.
56 JPEG identiques lors de deux extractions indépendantes.
Les 110 pages sont couvertes ; 54 répétitions de dos regroupées, aucune face supprimée.
Les détails raster restent limités par la résolution du PDF source.

Rejeu avec Python, PyMuPDF 2.0 et Pillow 12.1.1 :
python reproduction/cards.py extract recipe.json --source s0 "CHEMIN_DU_PDF_SOURCE.pdf" --out "cyberware-rejoue"
Le dossier de sortie et le ZIP voisin doivent être inexistants.
