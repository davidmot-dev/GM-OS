Menaces de la Cyberpapauté — extraction vérifiée le 08/11/2026

30 menaces, chacune dans son dossier : 0.jpg pour le recto illustré destiné aux joueurs, back.jpg pour le verso de statistiques du meneur.
60 JPEG de cartes et 2 JPEG d’instructions (instructions/recto.jpg et instructions/verso.jpg).
Les préfixes 01 à 30 des dossiers préservent l’ordre du PDF. Chaque numérotation commence à 0 selon le choix de David.
62 empreintes SHA-256 identiques après deux extractions. Aucun verso distinct regroupé ou supprimé.
Le graphisme, les titres, les statistiques et les textes du PDF source sont conservés sans retouche.

Rejeu avec Python, PyMuPDF 2.0 et Pillow 12.1.1 :
python reproduction/cards.py extract recipe.json --source s0 "CHEMIN_DU_PDF_SOURCE.pdf" --out "menaces-rejouees"
python reproduction/instructions.py recipe.json --source "CHEMIN_DU_PDF_SOURCE.pdf" --out "menaces-rejouees"
La première commande recrée les cartes et le ZIP voisin ; la seconde ajoute les instructions au dossier.
Le dossier de sortie et le ZIP voisin doivent être inexistants avant la première commande.
