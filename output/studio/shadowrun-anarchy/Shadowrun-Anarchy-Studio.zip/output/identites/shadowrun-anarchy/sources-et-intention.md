# Shadowrun : Anarchy 2.0 — identité d’images

Les trois illustrations fournies ont en commun une peinture numérique figurative,
des touches visibles et des bords fragmentés, des volumes semi-réalistes et une profondeur
atmosphérique. Des ombres bleues et des matières irrégulières soutiennent des lumières colorées
sélectives ; les reflets gardent une forme peinte et une intensité variable.

Références examinées : `Screenshot 2026-10-30 163416.png`, `163541.png`, `163635.png`, dans
`docs/Reference/Shadowrun Anarchy/`. Le bloc retient des choix de rendu communs, sans imposer
de personnage, objet ou lieu ; il ne reproduit aucun logo ou titre et ne nomme aucun artiste.
Le jaune et le papier du thème d’interface ne sont pas imposés comme fond à chaque illustration.

`identite-visuelle.md` porte exactement deux lignes en anglais : STYLE **42 mots**, AVOID
**15 mots**. Structure et longueur contrôlées par le validateur du plugin, sens relu.
Dans l’éditeur du pilote, ouvrir **Identité visuelle** et copier les textes après STYLE: et
AVOID: dans **Style / À éviter**. Le fichier définit une identité de jeu ; aucun pilote
personnel ou complément de campagne n’a été modifié.

La bannière est une composition originale distincte : son décor ne fait pas partie du bloc
de style générique. Son invite exacte est conservée dans `output/bannieres/shadowrun-anarchy/`.
