import React, { useState, useEffect, Suspense, lazy, useCallback } from 'react';
import { useSessionStore } from './store/useSessionStore';
import Shell from './components/Shell';
import { useModalStore } from './stores/useModalStore';
import SplashScreenSelector from './components/splash/SplashScreenSelector';
import ErrorBoundary from './components/common/ErrorBoundary';
import LoadingOverlay from './components/common/LoadingOverlay';

// --- STORES (Safe for Web) ---
import { useSoundStore } from './modules/sound/useSoundStore';
import { useStoryboardStore } from './modules/storyboard/useStoryboardStore';
import { useMapStore } from './modules/map/useMapStore';
import { useCombatStore } from './modules/combat/useCombatStore';
import { useSessionOSStore } from './modules/session/useSessionOSStore';
import { useFavoriteStore } from './modules/favorite/useFavoriteStore';
import { useWhiteboardStore, type Point, type DrawingPath, type WhiteboardTool } from './modules/whiteboard/useWhiteboardStore';
import { useClockStore } from './store/useClockStore';
import { useMusicStore } from './modules/music/useMusicStore';
import { useImageStore } from './modules/image/useImageStore';
import { useAmbientStore } from './modules/ambient/useAmbientStore';
import { useDiceStore } from './stores/useDiceStore';
import { useAIStore } from './stores/useAIStore';
import { useLightStore } from './modules/light/useLightStore';
import { BootstrapService } from './modules/system/logic/BootstrapService';
import { useHydration } from './hooks/useHydration';
import { useHueAutoConnect } from './modules/light/hooks/useHueAutoConnect';
import { DiceEngine } from './modules/dice/DiceEngine';
import { getDifferentialPayload } from './utils/syncUtils';
import { useDisplayDetection } from './hooks/useDisplayDetection';
import { resolveToSendableUrl } from './utils/mediaResolver';
import { useNexusSynchronizer } from './modules/remote/hooks/useNexusSynchronizer';

interface RemoteAction {
  type: string;
  payload?: any;
}

// --- LAZY COMPONENTS (Critical for Remote Stability) ---
const RemoteControl = lazy(() => import('./modules/remote/RemoteControl'));
const SessionDashboard = lazy(() => import('./modules/session/SessionDashboard'));
const DiceBoard = lazy(() => import('./modules/dice/DiceBoard'));
const MusicDashboard = lazy(() => import('./modules/music/MusicDashboard'));
const CombatDashboard = lazy(() => import('./modules/combat/CombatDashboard'));
const NPCDashboard = lazy(() => import('./modules/npc/NPCDashboard'));
const MapDashboard = lazy(() => import('./modules/map/MapDashboard'));
const ClockDashboard = lazy(() => import('./modules/clock/ClockDashboard'));
const AmbientDashboard = lazy(() => import('./modules/ambient/AmbientDashboard'));
const TableDashboard = lazy(() => import('./modules/tables/TableDashboard'));
const WebDashboard = lazy(() => import('./modules/web/WebDashboard'));
const ImageDashboard = lazy(() => import('./modules/image/ImageDashboard'));
const SoundDashboard = lazy(() => import('./modules/sound/SoundDashboard'));
const LightDashboard = lazy(() => import('./modules/light/LightDashboard'));
const WhiteboardDashboard = lazy(() => import('./modules/whiteboard/WhiteboardDashboard'));
const DebugDashboard = lazy(() => import('./modules/debug/DebugDashboard'));
const VoiceDashboard = lazy(() => import('./modules/voice/VoiceDashboard'));
const ProjectorView = lazy(() => import('./modules/image/components/ProjectorView'));
const PlayerHub = lazy(() => import('./components/PlayerHub'));
const TabletHub = lazy(() => import('./components/TabletHub'));
const ObsidianPanel = lazy(() => import('./modules/session/components/ObsidianPanel'));
const JournalDashboard = lazy(() => import('./modules/journal/JournalDashboard'));
const FavoriteDashboard = lazy(() => import('./modules/favorite/components/FavoriteDashboard').then(m => ({ default: m.FavoriteDashboard })));

// --- SHARED COMPONENTS ---
const ModalProvider = lazy(() => import('./components/ModalProvider'));
const ToastProvider = lazy(() => import('./components/ToastProvider'));
const AudioRouter = lazy(() => import('./modules/music/components/AudioRouter'));
const MediaBrowser = lazy(() => import('./components/MediaBrowser').then(m => ({ default: m.MediaBrowser })));
const GlobalKeybinds = lazy(() => import('./components/GlobalKeybinds').then(m => ({ default: m.GlobalKeybinds })));
const SpotlightSearch = lazy(() => import('./components/SpotlightSearch').then(m => ({ default: m.SpotlightSearch })));
const MessageAlertOverlay = lazy(() => import('./modules/session/components/MessageAlertOverlay').then(m => ({ default: m.MessageAlertOverlay })));
const BrainstormOverlay = lazy(() => import('./modules/forge/rules/components/BrainstormOverlay').then(m => ({ default: m.BrainstormOverlay })));

const PlaceholderModule = ({ name }: { name: string }) => (
  <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
    <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center animate-pulse">
      <div className="w-8 h-8 rounded-full bg-slate-700" />
    </div>
    <h2 className="text-3xl font-bold tracking-tight">Module {name}</h2>
  </div>
);

interface UniversalPad {
  id: string;
  type: 'music' | 'sound' | 'image' | 'ambient';
  label: string;
  color: string;
  imageUrl?: string;
  sublabel?: string;
}

function App() {
  const { activeModule, theme } = useSessionStore();
  const sessionOSStore = useSessionOSStore();
  const { activeCampaignId } = sessionOSStore;
  const { isMediaHubOpen, closeMediaHub } = useModalStore();
  const { syncWithKeychain: syncAIKeys } = useAIStore();
  const { syncWithKeychain: syncHueKeys } = useLightStore();
  const [showSplash, setShowSplash] = useState(true);

  const searchParams = new URLSearchParams(window.location.search);
  const isProjector = searchParams.get('window') === 'projector';
  const isHub = searchParams.get('window') === 'hub';
  const isTablet = searchParams.get('window') === 'tablet';
  const isRemote = searchParams.get('window') === 'remote';

  // Workspace Sync v3: Modularized via useNexusSynchronizer
  const isMainPC = !isProjector && !isHub && !isTablet && !isRemote;
  const isHydrated = useHydration();
  const isSystemReady = useSessionStore(state => state.isSystemReady);
  
  // Nexus Sync Engine Integration
  const { handleSync } = useNexusSynchronizer(isMainPC);

  // Le système est "prêt" si hydraté et (si Main PC) si le bootstrap est fini
  const isAppReady = isHydrated && (isMainPC ? isSystemReady : true);

  useDisplayDetection(isMainPC);
  
  // --- AUTO-CONNECT HUE BRIDGES (GM SEULEMENT) ---
  useHueAutoConnect(isMainPC);
  
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    if (isMainPC && isHydrated) {
      syncAIKeys();
      syncHueKeys();
    }
  }, [isMainPC, isHydrated, syncAIKeys, syncHueKeys]);

  // --- BOOTSTRAP DU SYSTÈME (GM SEULEMENT) ---
  useEffect(() => {
    if (isMainPC && isHydrated && !isSystemReady) {
      BootstrapService.bootstrap();
    }
  }, [isMainPC, isHydrated, isSystemReady]);

  // --- MESSAGING BRIDGE (GM SIDE) ---
  useEffect(() => {
    if (!isMainPC) return;

    const handleSendMessage = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (window.appBridge?.remote?.broadcastUIAction) {
        window.appBridge.remote.broadcastUIAction({
          type: 'session:receive-message',
          payload: customEvent.detail
        });
      }
    };

    window.addEventListener('session:send-message', handleSendMessage);
    return () => window.removeEventListener('session:send-message', handleSendMessage);
  }, [isMainPC]);

  const handleAction = useCallback((data: RemoteAction) => {
    const { type, payload } = data;
    
    console.log(`[App] [RemoteAction] type: ${type}`, payload);

    // --- DICE ACTIONS ---
    if (type === 'dice:roll' || type === 'remote:dice:roll') {
      const p = payload as { 
        sides?: number, 
        die?: number, 
        count?: number, 
        modifier?: number, 
        mode?: string, 
        target?: number, 
        title?: string, 
        formula?: string,
        gearCount?: number, 
        useSystem?: boolean 
      };
      const sides = p.sides || p.die || 20;
      const count = p.count || 1;
      const modifier = p.modifier || 0;
      const mode = p.mode || 'standard';
      const target = p.target || 10;
      
      console.log(`[App] Global Dice Roll: ${count}d${sides} (${mode})`);
      
      const activeDriver = sessionOSStore.getActiveDriver();
      let result;
      let finalTitle = p.title || `${count}d${sides}`;

      // 1. Priorité au Mode Système si explicitement demandé
      if (p.useSystem && activeDriver) {
        result = DiceEngine.rollFromConfig(activeDriver.dice, {
          modifier,
          baseCount: count,
          gearCount: p.gearCount || 0,
          targetOverwrite: target
        });
        finalTitle = p.title || `Système (${activeDriver.name})`;
      } else {
        // 2. Fallback sur la logique manuelle étendue
        switch (mode) {
          case 'standard': 
            result = DiceEngine.rollStandard(sides, count, modifier); 
            break;
          case 'exploding': 
            result = DiceEngine.rollStandard(sides, count, modifier, true); 
            break;
          case 'threshold': 
            result = DiceEngine.rollThreshold(sides, count, modifier, target); 
            break;
          case 'pool': 
            result = DiceEngine.rollPool(sides, count, modifier, target); 
            break;
          case 'pool_explode': 
            result = DiceEngine.rollPool(sides, count, modifier, target, true); 
            break;
          case 'advantage': 
            result = DiceEngine.rollAdvantage(sides, modifier, true, target); 
            break;
          case 'disadvantage': 
            result = DiceEngine.rollAdvantage(sides, modifier, false, target); 
            break;
          case 'yze': 
            result = DiceEngine.rollYZE(count, p.target || p.gearCount || 0); 
            break;
          case 'fate': 
            result = DiceEngine.rollFate(count, modifier); 
            break;
          case 'rolemaster': 
            result = DiceEngine.rollRolemaster(modifier); 
            break;
          case 'formula':
            result = DiceEngine.rollFormula(p.formula || p.title || '1d20'); 
            break;
          default: 
            result = DiceEngine.rollStandard(sides, count, modifier);
        }
      }

      const record = {
        ...result,
        id: Math.random().toString(36).substring(7),
        timestamp: new Date(),
        title: finalTitle
      };

      const diceStore = useDiceStore.getState();
      diceStore.setLastRoll(record);

      if (diceStore.isDiceProjected) {
        diceStore.triggerDiceProjection();
      }
    }
    
    if (type === 'dice:clear' || type === 'remote:dice:clear' || type === 'remote:dice:clear-dice') {
      console.log('[App] Global Clear Dice action');
      useDiceStore.getState().clearHistory();
    }

    // --- SYNC ACTIONS ---
    if (type === 'remote:request-sync') {
      console.log('[App] Forced sync request from tablet');
      handleSync(true); // Force full sync broadcast
    }

    // --- SOUND ACTIONS ---
    if (type === 'sound:trigger' || type === 'remote:sound:trigger') {
        const soundId = (payload as { id?: string }).id || (payload as { padId?: string }).padId || '';
        console.log(`[App] Remote Trigger Sound (+Lights): ${soundId}`, payload);
        if (soundId) {
            import('./modules/sound/SoundController').then(({ soundController }) => {
                soundController.togglePad(soundId);
            });
        }
    }
    if (type === 'sound:volume' || type === 'remote:sound:volume') {
        useSoundStore.getState().setMasterVolume((payload as { volume: number }).volume);
    }
    if (type === 'sound:stop-all' || type === 'remote:sound:stop-all') {
        useSoundStore.getState().stopAllPads();
    }
    
    // --- COMBAT ACTIONS ---
    if (type === 'combat:update-hp' || type === 'remote:combat:hp') {
      const { id, delta } = payload as { id: string; delta: number };
      const c = useCombatStore.getState().combatants.find(c => c.id === id);
      if (c) useCombatStore.getState().updateCombatant(id, { hp: Math.min(c.hpMax, Math.max(0, c.hp + delta)) });
    }
    if (type === 'combat:next-turn' || type === 'remote:combat:next') {
      useCombatStore.getState().nextTurn();
    }

    // --- SESSION ACTIONS ---
    if (type === 'session:update-character-narrative' || type === 'remote:session:update-character-narrative') {
      const { playerId, characterId, updates } = payload as { playerId: string; characterId: string; updates: any };
      useSessionOSStore.getState().updateCharacterNarrative(playerId, characterId, updates);
    }

    if (type === 'session:send-message') {
      console.log('[App] Receiving player message from remote:', payload.id);
      useSessionOSStore.getState().addSessionMessage(payload as import('./modules/session/store/types').SessionMessage);
    }

    if (type === 'session:request-item-transfer' || type === 'remote:session:request-item-transfer') {
      const { fromCharId, toCharId, item } = payload as { fromCharId: string; toCharId: string; item: any };
      console.log(`[App] Receiving transfer request: ${item.name} from ${fromCharId} to ${toCharId}`);
      useSessionOSStore.getState().requestItemTransfer(fromCharId, toCharId, item);
    }

    if (type === 'session:approve-item-transfer' || type === 'remote:session:approve-item-transfer') {
      const { requestId } = payload as { requestId: string };
      useSessionOSStore.getState().approveItemTransfer(requestId);
    }

    if (type === 'session:reject-item-transfer' || type === 'remote:session:reject-item-transfer') {
      const { requestId } = payload as { requestId: string };
      useSessionOSStore.getState().rejectItemTransfer(requestId);
    }

    if (type === 'session:remove-inventory-item' || type === 'remote:session:remove-inventory-item') {
      const { playerId, characterId, itemId } = payload as { playerId: string; characterId: string; itemId: string };
      useSessionOSStore.getState().removeInventoryItem(playerId, characterId, itemId);
    }

    if (type === 'storyboard:trigger' || type === 'remote:story:trigger') {
      const storyboard = useStoryboardStore.getState();
      const moments = storyboard.moments.filter(m => m.campaignId === activeCampaignId);
      const m = moments[(payload as { index: number }).index];
      if (m) storyboard.triggerMoment(m.id);
    }

    if (type === 'whiteboard:set-laser-pointer') {
      useWhiteboardStore.getState().setLaserPointer(payload as unknown as Point);
    }
    if (type === 'whiteboard:set-active-path') {
      useWhiteboardStore.getState().setActivePath((payload as { path: DrawingPath }).path, (payload as { drawerId: string }).drawerId);
    }
    if (type === 'whiteboard:draw' || type === 'whiteboard:add-path') {
      useWhiteboardStore.getState().addPath(payload as unknown as DrawingPath);
    }
    if (type === 'whiteboard:set-tool') {
      useWhiteboardStore.getState().setTool(payload as WhiteboardTool);
    }
    if (type === 'whiteboard:set-color') {
      useWhiteboardStore.getState().setColor(payload as string);
    }
    if (type === 'whiteboard:set-width') {
      useWhiteboardStore.getState().setWidth(payload as number);
    }
    if (type === 'whiteboard:clear') {
      useWhiteboardStore.getState().clearBoard();
    }
    if (type === 'whiteboard:undo') {
      useWhiteboardStore.getState().undo();
    }
    if (type === 'whiteboard:redo') {
      useWhiteboardStore.getState().redo();
    }

    // --- UNIVERSAL PADS TRIGGER ---
    if (type === 'remote:pad:trigger' || type === 'universal:trigger') {
      const { id } = payload as { id: string };
      console.log(`[App] [Remote:Pad:Trigger] id: ${id}`);

      // 1. Check Music
      const musicStore = useMusicStore.getState();
      const musicPad = musicStore.playlists.flatMap(p => p.pads).find(p => p.id === id);
      if (musicPad) {
        console.log(`[App] Triggering Music Pad: ${musicPad.label}`);
        musicStore.playPad(musicPad);
        handleSync(true);
        return;
      }

      // 2. Check Sound (SFX)
      const soundStore = useSoundStore.getState();
      const activeAtmos = soundStore.atmospheres.find(a => a.id === soundStore.activeAtmosphereId) || soundStore.atmospheres[0];
      if (activeAtmos && activeAtmos.pads[id]) {
          console.log(`[App] Triggering Sound Pad: ${id}`);
          import('./modules/sound/SoundController').then(({ soundController }) => {
              soundController.togglePad(id);
          });
          handleSync(true);
          return;
      }

      // 3. Check Image
      const imageStore = useImageStore.getState();
      const image = imageStore.mediaList.find(m => m.id === id);
      if (image) {
        console.log(`[App] Triggering Image Pad (Projection): ${image.name}`);
        imageStore.projectSolo(image);
        handleSync(true);
        return;
      }

      // 4. Check Ambient
      const ambientStore = useAmbientStore.getState();
      const ambientPreset = ambientStore.presets.find(p => p.id === id);
      if (ambientPreset) {
        console.log(`[App] Triggering Ambient Preset: ${ambientPreset.name}`);
        ambientStore.loadTheme(ambientPreset.universe, ambientPreset.name);
        handleSync(true);
        return;
      }
    }

    // Trigger an immediate sync after any remote action, EXCEPT high-frequency ones
    const highFreqActions = ['whiteboard:set-active-path', 'whiteboard:set-laser-pointer'];
    if (!highFreqActions.includes(type)) {
      handleSync(true);
    }
  }, [activeCampaignId, handleSync]);

  // Handle Remote Sync and Actions (Only on Main PC Window)
  useEffect(() => {
    const bridge = window.appBridge;
    if (!bridge?.remote || !isMainPC) return;

    // Synchroniser automatiquement la carte si le Combat-OS change (pour l'invisibilité des jetons liés)
    const unsubscribeCombat = useCombatStore.subscribe((state, prevState) => {
      if (state.combatants !== prevState.combatants) {
        useMapStore.getState().syncToPlayers();
      }
    });

    bridge.on('remote:request-sync', (_event) => {
        handleSync(true);
    });

    bridge.on('remote:sync-clients', (_event, clients: import('./types/shared').ClientContext[]) => {
        if (!clients || !Array.isArray(clients)) return;
        const locks: Record<string, string> = {};
        clients.forEach(c => {
            if ((c.status === 'active' || c.status === 'ghost') && c.characterId) {
                locks[c.characterId] = c.deviceId;
            }
        });
        useSessionOSStore.getState().setCharacterLocks(locks);
    });
    
    bridge.remote.removeActions();
    const cleanupAction = bridge.remote.onAction(handleAction);

    return () => {
      cleanupAction();
      unsubscribeCombat();
      console.log('[App] Remote action listeners removed.');
    };
  }, [handleSync, isMainPC, handleAction]);

  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard': return <ErrorBoundary moduleName="Dashboard"><SessionDashboard /></ErrorBoundary>;
      case 'dice': return <ErrorBoundary moduleName="Dice OS"><DiceBoard /></ErrorBoundary>;
      case 'music': return <ErrorBoundary moduleName="Music OS"><MusicDashboard /></ErrorBoundary>;
      case 'combat': return <ErrorBoundary moduleName="Combat OS"><CombatDashboard /></ErrorBoundary>;
      case 'map': return <ErrorBoundary moduleName="Map OS"><MapDashboard /></ErrorBoundary>;
      case 'npc': return <ErrorBoundary moduleName="NPC OS"><NPCDashboard /></ErrorBoundary>;
      case 'clock': return <ErrorBoundary moduleName="Clock OS"><ClockDashboard /></ErrorBoundary>;
      case 'ambient': return <ErrorBoundary moduleName="Ambient OS"><AmbientDashboard /></ErrorBoundary>;
      case 'table': return <ErrorBoundary moduleName="Table OS"><TableDashboard /></ErrorBoundary>;
      case 'web': return <ErrorBoundary moduleName="Web OS"><WebDashboard /></ErrorBoundary>;
      case 'image': return <ErrorBoundary moduleName="Image OS"><ImageDashboard /></ErrorBoundary>;
      case 'sound': return <ErrorBoundary moduleName="Sound OS"><SoundDashboard /></ErrorBoundary>;
      case 'light': return <ErrorBoundary moduleName="Light OS"><LightDashboard /></ErrorBoundary>;
      case 'favorite': return <ErrorBoundary moduleName="Favorite OS"><FavoriteDashboard /></ErrorBoundary>;
      case 'whiteboard': return <ErrorBoundary moduleName="Whiteboard OS"><WhiteboardDashboard /></ErrorBoundary>;
      case 'debug': return <ErrorBoundary moduleName="Debug OS"><DebugDashboard /></ErrorBoundary>;
      case 'voice': return <ErrorBoundary moduleName="Voice OS"><VoiceDashboard /></ErrorBoundary>;
      case 'obsidian': return <ErrorBoundary moduleName="Obsidian Panel"><ObsidianPanel /></ErrorBoundary>;
      case 'journal': return <ErrorBoundary moduleName="Journal OS"><JournalDashboard /></ErrorBoundary>;
      default: return <PlaceholderModule name={activeModule} />;
    }
  };

  const pathname = window.location.pathname.toLowerCase();
  const isProjectorView = searchParams.get('window') === 'projector' || pathname.includes('/projector');
  const isHubView = searchParams.get('window') === 'hub' || pathname.includes('/player-hub');
  const isTabletView = searchParams.get('window') === 'tablet' || pathname.includes('/tablet-hub');
  const isRemoteView = searchParams.get('window') === 'remote' || pathname.includes('/remote');

  if (!isAppReady) {
    return <div className="h-screen w-screen bg-black flex items-center justify-center">
      <div className="text-cyan-500 font-mono animate-pulse">GM-OS BOOTING...</div>
    </div>;
  }

  return (
    <Suspense fallback={<div className="h-screen w-screen bg-black" />}>
      {isRemoteView ? (
        <ErrorBoundary moduleName="Remote Control"><RemoteControl /></ErrorBoundary>
      ) : isProjectorView ? (
        <ErrorBoundary moduleName="Projector View"><ProjectorView /></ErrorBoundary>
      ) : isHubView ? (
        <ErrorBoundary moduleName="Player Hub"><PlayerHub /></ErrorBoundary>
      ) : isTabletView ? (
        <ErrorBoundary moduleName="Tablet Hub"><TabletHub /></ErrorBoundary>
      ) : (
        <>
          <GlobalKeybinds />
          <SpotlightSearch />
          <ModalProvider />
          <ToastProvider />
          <AudioRouter />
          <MediaBrowser isOpen={isMediaHubOpen} onClose={closeMediaHub} onSelect={() => {}} title="MEDIA HUB" />
          <LoadingOverlay />
          {showSplash && <SplashScreenSelector onComplete={() => setShowSplash(false)} />}
          
          <Suspense fallback={null}>
            <MessageAlertOverlay />
            <BrainstormOverlay />
          </Suspense>
          
          <Shell>{renderModule()}</Shell>
        </>
      )}
    </Suspense>
  );
}

export default App;
