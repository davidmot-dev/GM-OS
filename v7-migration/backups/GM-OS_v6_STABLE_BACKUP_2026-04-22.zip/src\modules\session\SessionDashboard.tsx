import React, { useState } from 'react';
import SessionHeader from './components/SessionHeader';
import SessionViewRegistry from './components/SessionViewRegistry';
import OraclePanel from './components/OraclePanel';
import SessionSnapshotModal from './components/SessionSnapshotModal';
import RemoteNotificationCenter from './components/RemoteNotificationCenter';
import { useSessionOSStore } from './useSessionOSStore';
import { DEFAULT_SHEET_TEMPLATES } from '../../data/defaultSheetTemplates';
import { DEFAULT_GAME_DRIVERS } from '../../data/defaultGameDrivers';

/**
 * SessionDashboard - Point d'entrée principal de l'OS de Session.
 * Architecture modulaire (Phase 8) utilisant le Registry Pattern pour les vues.
 */
const SessionDashboard: React.FC = () => {
    const { 
        activeCampaignId, 
        campaigns, 
        customSheetTemplates,
        customGameDrivers,
        isHeaderHidden
    } = useSessionOSStore();

    const [isOracleOpen, setIsOracleOpen] = useState(false);
    const [isSnapshotModalOpen, setIsSnapshotModalOpen] = useState(false);
    const [forgeMode, setForgeMode] = useState<'system' | 'chronicle'>('system');

    // Résolution contextuelle réactive (Phase 8 Logic)
    const { activeCampaign, activeDriver, activeTemplate } = React.useMemo(() => {
        const camp = campaigns.find(c => c.id === activeCampaignId);
        const driver = [...DEFAULT_GAME_DRIVERS, ...customGameDrivers].find(d => d.id === camp?.system);
        const template = [...DEFAULT_SHEET_TEMPLATES, ...customSheetTemplates].find(t => t.id === camp?.system);
        
        return { activeCampaign: camp, activeDriver: driver, activeTemplate: template };
    }, [activeCampaignId, campaigns, customGameDrivers, customSheetTemplates]);

    const driverNotebookUrl = activeDriver?.defaultNotebookUrl;
    const templateNotebookUrl = activeTemplate?.defaultNotebookUrl;

    return (
        <div className={`flex-1 ${isHeaderHidden ? 'h-screen' : 'h-[calc(100vh-64px)]'} overflow-hidden flex flex-col bg-app-bg text-app-text font-display transition-all duration-500`}>
            {/* Header modulaire (Navigation & Utilitaires) */}
            {!isHeaderHidden && (
                <SessionHeader 
                    isOracleOpen={isOracleOpen}
                    setIsOracleOpen={setIsOracleOpen}
                    setIsSnapshotModalOpen={setIsSnapshotModalOpen}
                    forgeMode={forgeMode}
                    setForgeMode={setForgeMode}
                />
            )}

            {/* Registre de Vues (Contenu principal dynamique) */}
            <SessionViewRegistry forgeMode={forgeMode} />

            {/* Overlays & Panneaux persistants */}
            <OraclePanel 
                isOpen={isOracleOpen} 
                onClose={() => setIsOracleOpen(false)} 
                campaignNotebookUrl={activeCampaign?.notebookUrl}
                templateNotebookUrl={templateNotebookUrl}
                driverNotebookUrl={driverNotebookUrl}
            />

            {isSnapshotModalOpen && (
                <SessionSnapshotModal onClose={() => setIsSnapshotModalOpen(false)} />
            )}

            {/* Notifications Distantes (Tablet HUB Sync) */}
            <RemoteNotificationCenter />
        </div>
    );
};

export default SessionDashboard;
