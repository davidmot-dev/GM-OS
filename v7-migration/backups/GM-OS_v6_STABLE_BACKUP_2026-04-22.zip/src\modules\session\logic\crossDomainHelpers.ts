import { gmToast } from '../../../stores/useToastStore';
import type { SessionOSStore } from '../store/index';
import type { Campaign, Entity, AtlasMap, WikiEntry, EntityRelation } from '../store/types';

export const handleAddChronicle = (
    set: (partial: Partial<SessionOSStore> | ((state: SessionOSStore) => Partial<SessionOSStore>)) => void,
    get: () => SessionOSStore,
    payload: {
        campaign: Omit<Campaign, 'id'> & { id?: string };
        entities: (Omit<Entity, 'id' | 'campaignId' | 'relations'> & {
            relations?: { targetName: string; type: EntityRelation['type']; description: string }[];
        })[];
        atlasMaps: Omit<AtlasMap, 'id' | 'campaignId'>[];
        wikiEntries: Omit<WikiEntry, 'id' | 'campaignId'>[];
        existingCampaignId?: string;
    }
) => {
    const { campaign, entities, atlasMaps, wikiEntries, existingCampaignId } = payload;
    const state = get();
    const existing = existingCampaignId 
        ? state.campaigns.find(c => c.id === existingCampaignId)
        : state.campaigns.find(c => c.name.toLowerCase() === campaign.name.toLowerCase());
        
    const campaignId = existing ? existing.id : `c-${Date.now()}`;

    const entityIdMap: Record<string, string> = {};
    const newEntities: Entity[] = entities.map((e) => {
        const id = `e-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        if (e.name) {
            entityIdMap[e.name] = id;
        }
        return { ...e, id, campaignId, relations: [] } as Entity;
    });

    newEntities.forEach((entity, idx) => {
        const rawRelations = entities[idx].relations ?? [];
        entity.relations = rawRelations.map((r) => ({
            targetId: r.targetName ? (entityIdMap[r.targetName as string] ?? '') : '',
            targetType: 'npc' as const,
            type: r.type as EntityRelation['type'],
            description: r.description,
        })).filter((r) => r.targetId);
    });

    const newAtlasMaps: AtlasMap[] = atlasMaps.map((m) => ({
        ...m,
        id: `am-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        campaignId,
        linkedEntities: [],
    } as unknown as AtlasMap));

    const newWikiEntries: WikiEntry[] = wikiEntries.map((w) => ({
        ...w,
        id: `we-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        campaignId,
    } as unknown as WikiEntry));

    set((state) => {
        const updatedCampaigns = existing 
            ? state.campaigns.map(c => c.id === existing.id ? { ...c, system: campaign.system || c.system } : c)
            : [...state.campaigns, { ...campaign, id: campaignId, activeLocationIds: [] } as unknown as Campaign];

        return {
            campaigns: updatedCampaigns,
            entities: [...state.entities, ...newEntities],
            atlasMaps: [...state.atlasMaps, ...newAtlasMaps],
            wikiEntries: [...state.wikiEntries, ...newWikiEntries],
            activeCampaignId: campaignId,
            currentView: 'cockpit',
        };
    });

    const msg = existing 
        ? `Chronique fusionnée avec "${existing.name}". ${newEntities.length} entités ajoutées.`
        : `Chronique "${campaign.name}" importée avec ${newEntities.length} entités.`;
    gmToast(msg, 'success');
};


export const handleGenerateEntityPortrait = async (
    set: (partial: Partial<SessionOSStore> | ((state: SessionOSStore) => Partial<SessionOSStore>)) => void,
    get: () => SessionOSStore,
    entityId: string, 
    instructions?: string
) => {
    const entity = get().entities.find((e) => e.id === entityId);
    if (!entity) return;
    set({ isGeneratingAIImage: true });
    try {
        const { aiService } = await import('../../ai/AIService');
        const cleanDesc = (entity.description || '').replace(/\n/g, ' ').substring(0, 300);
        const prompt = instructions ?? `A professional fantasy RPG character portrait of ${entity.name}. ${cleanDesc}. High quality digital art, cinematic lighting, 8k.`;
        const mediaId = await aiService.generateImage(prompt);
        get().updateEntity(entityId, { avatar: mediaId });
    } catch (err) {
        console.error('AI Portrait Error:', err);
    } finally {
        set({ isGeneratingAIImage: false });
    }
};

export const handleGenerateAtlasMapImage = async (
    set: (partial: Partial<SessionOSStore> | ((state: SessionOSStore) => Partial<SessionOSStore>)) => void,
    get: () => SessionOSStore,
    mapId: string, 
    instructions?: string
) => {
    const map = get().atlasMaps.find((m) => m.id === mapId);
    if (!map) return;
    set({ isGeneratingAIImage: true });
    try {
        const { aiService } = await import('../../ai/AIService');
        const cleanDesc = (map.narrativeDescription || '').replace(/\n/g, ' ').substring(0, 300);
        const prompt = instructions ?? `Fantasy RPG environment art: ${map.name}. ${cleanDesc}. Cinematic, epic scale, high quality.`;
        const mediaId = await aiService.generateImage(prompt);
        get().updateAtlasMap(mapId, { fileUrl: mediaId, isVideo: false });
    } catch (err) {
        console.error('AI Map Error:', err);
    } finally {
        set({ isGeneratingAIImage: false });
    }
};

export const handleGeneratePlayerPortrait = async (
    set: (partial: Partial<SessionOSStore> | ((state: SessionOSStore) => Partial<SessionOSStore>)) => void,
    get: () => SessionOSStore,
    playerId: string, 
    characterId: string, 
    instructions?: string
) => {
    const player = get().players.find((p) => p.id === playerId);
    const char = player?.characters.find((c) => c.id === characterId);
    if (!char) return;
    set({ isGeneratingAIImage: true });
    try {
        const { aiService } = await import('../../ai/AIService');
        const prompt = `A heroic character portrait of ${char.name}. ${char.classRace}. Professional digital art, cinematic lighting, 8k. ${instructions ? `Additional: ${instructions}` : ''}`;
        const mediaId = await aiService.generateImage(prompt);
        get().updateCharacterVisuals(playerId, characterId, { portraitUrl: mediaId });
    } catch (err) {
        console.error('AI Player Portrait Error:', err);
    } finally {
        set({ isGeneratingAIImage: false });
    }
};

export const handleExportActiveCampaignToObsidian = async (
    get: () => SessionOSStore
) => {
    const { obsidianExportService } = await import('../ObsidianExportService');
    const state = get();
    const campaign = state.campaigns.find((c) => c.id === state.activeCampaignId);
    if (!campaign) return;
    await obsidianExportService.exportCampaign(campaign, state.entities, state.atlasMaps, state.wikiEntries);
};
